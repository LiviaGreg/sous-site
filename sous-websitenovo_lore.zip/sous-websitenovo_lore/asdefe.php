<body class="ong-page">

    <header class="ong-header">
        <link rel="stylesheet" href="styles.css">
        <h1>As de fe</h1>
        <p>De quem ajuda, para quem ajuda! </p>
    </header>
    <!-- Conteúdo da página -->
    
    <div class="perfil">
        <a href= "https://www.instagram.com/asdefe.eunapolis?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==">
            <img src="asdefe.jpg" title= "Site de ONG apoiando vidas">
        </a>

    </div>

    <div class="content">
        <h4>A ASDEFE Eunápolis é uma organização sem fins lucrativos que atua na cidade de Eunápolis, Bahia, oferecendo apoio e assistência a pessoas com deficiência e suas famílias. A organização trabalha para promover a inclusão social e melhorar a qualidade de vida de seus membros, desenvolvendo atividades que visam estimular o desenvolvimento e bem-estar de seus beneficiários. Além disso, a ASDEFE realiza eventos e campanhas para conscientizar a comunidade sobre a importância de uma sociedade mais inclusiva e acessível para todos</h4>
        <p>Veja abaixo os dados da ONG, e como ajudá-la.</p>

        <div class="tabela-container">
            <table>
                <tr>
                    <td>CNPJ</td>
                    <td>33425036000176</td>
                </tr>
                <tr>
                    <td>Telefone</td>
                    <td>123456789</td>
                </tr>
            </table>
        </div>
    </div>
    
    
    <div class="rodape">
        <p> ©apoiando_vidas - Sous. </p>
    </div>
</body>