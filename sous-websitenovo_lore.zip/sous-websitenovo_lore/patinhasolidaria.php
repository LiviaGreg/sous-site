<body class="ong-page">

    <header class="ong-header">
        <link rel="stylesheet" href="styles.css">
        <h1>Patinha Solidária</h1>
        <p>De quem ajuda, para quem ajuda! </p>
    </header>
    <!-- Conteúdo da página -->
    
    <div class="perfil">
        <a href= "https://www.instagram.com/patinha_eunapolis/">
            <img src="patinha.png" title= "Site de Patinha Solidária">
        </a>

    </div>

    <div class="content">
        <h4>A ONG Patinha Solidária é uma organização social que fica em Eunápolis, BA...</h4>
        <p>Veja abaixo os dados da ONG, e como ajudá-la.</p>

        <div class="tabela-container">
            <table>
                <tr>
                    <td>CNPJ</td>
                    <td>33425036000176</td>
                </tr>
                <tr>
                    <td>Telefone</td>
                    <td>123456789</td>
                </tr>
            </table>
        </div>
    </div>
    
    
    <div class="rodape">
        <p> ©Patinha Solidária - Sous. </p>
    </div>
</body>
    