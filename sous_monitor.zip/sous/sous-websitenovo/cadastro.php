<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylecadastro.css">
    <title>Cadastro - SOUS</title>
</head>
<body>
    <section class="cadastro-section">
        <div class="cadastro-container">
            <h2>Cadastro da ONG</h2>
            <form action="process_cadastro.php" method="post" enctype="multipart/form-data">
                <div class="form-row">
                    
                    <!-- Primeira Caixa -->
                    <div class="form-box">
                        <div class="input-box">
                            <label for="nome">Nome da ONG:</label>
                            <input type="text" id="nome" name="nome" placeholder="Nome da ONG" required>
                        </div>
                        <div class="input-box">
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" placeholder="Email" required>
                        </div>
                        <div class="input-box">
                            <label for="telefone">Telefone:</label>
                            <input type="tel" id="telefone" placeholder="Telefone" name="telefone" data-mask="(00) 00000-0000" required>
                        </div>
                        <div class="input-box">
                            <label for="cidade">Cidade:</label>
                            <input type="text" id="cidade" name="cidade" placeholder="Cidade" required>
                        </div>
                    </div>

                    <!-- Segunda Caixa -->
                    <div class="form-box">
                        <div class="input-box">
                            <label for="cnpj">CNPJ:</label>
                            <input type="text" id="cnpj" name="cnpj" placeholder="CNPJ" required>
                        </div>
                        <div class="input-box">
                            <label for="categoria">Categoria:</label>
                            <select id="categoria" name="categoria" required>
                                <option value="Animal">Animal</option>
                                <option value="Ambiental">Ambiental</option>
                                <option value="Social">Social</option>
                            </select>
                        </div>
                        <div class="input-box">
                            <label for="logo">Logo:</label>
                            <input type="file" id="logo" name="logo" required>
                        </div>
                        <div class="input-box">
                            <label for="senha">Senha:</label>
                            <input type="password" id="senha" name="senha" placeholder="Senha" required>
                        </div>
                    </div>
                </div>
                <button type="submit" class="submit-btn" name="cadastro">Cadastrar</button>
            </form>
            
        </div>
    </section>
    
    <script>
        function mostrarSenha() {
            var senhaInput = document.getElementById("senha");
            var tipo = senhaInput.type === "password" ? "text" : "password";
            senhaInput.type = tipo;
        }
    </script>
</body>
</html>