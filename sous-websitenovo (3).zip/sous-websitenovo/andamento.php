<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro em Análise - SOUS</title>
    <link rel="stylesheet" href="front/styles.css">
</head>
<body>
    <div class="loading-container">
        <div class="loading"></div> 
        <p class="message">Seu cadastro está em andamento esperando análise dos proprietarios da SOUS. </p>
        <p class="message"> Enquanto isso, conheça nossas ONGS já cadastradas. </p> <br><br>  
        <button type="submit" onclick="window.location.href='indexx.php'">Ver Ongs</button>
    </div>
    
</body>
</html>