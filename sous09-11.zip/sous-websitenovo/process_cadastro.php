<?php
// Inclui os arquivos PHP necessários para configuração e funções.
include "bdd.php";   // Inclui o arquivo com as configurações de conexão ao banco de dados.
include "funcaoerror.php";   // Inclui o arquivo com funções personalizadas.

// Extrai os dados da requisição POST em variáveis separadas.
extract($_POST);

// Verifica se o formulário foi enviado (o botão "cadastrar" foi clicado).
if (isset($cadastro)) {

    // Remove espaços em branco no início e no fim dos demais dados do formulário.
    $nome = trim($nome);
    $email = trim($email);
    $telefone = trim($telefone);
    $endereco = trim($endereco);
    $cnpj = trim($cnpj);
    $categoria = trim($categoria); 
    $senha = trim($senha);

    // Verifica se algum dos campos obrigatórios está vazio.
    if (empty($nome) || empty($email) || empty($telefone) || empty($cidade) || empty($CNPJ) || empty($categoria) || empty($senha)) {
        session_start();
        echo "Todos os campos devem ser preenchidos.";
        header("Location: cadastro.php");
        exit;
    }
    
    // Verifica se a matrícula já existe no banco de dados.
    $consulta = "SELECT COUNT(*) FROM usuarios WHERE CNPJ = '$CNPJ'";
    $resultado = banco($dbHost, $dbUsername, $dbPassword, $dbName, $consulta);
    $row = $resultado->fetch_row();
    if ($row[0] > 0) {
        session_start();
        echo "O CNPJ já está cadastrado.";
        header("Location: cadastro.php");
        exit;
    }
    
    // Verifica se a senha coincide com a confirmação de senha.
    //if ($senha === $confirmar_senha) { // hugo, como eu tiro essa verificação *ja q eu n tenho  confirmar senha) e peraneço com o if
        // Gera o hash da senha usando a função password_hash, para armazená-la de forma segura no banco de dados.
        //$senhaHash = password_hash($senha, PASSWORD_DEFAULT);
    
        // Insere o usuário no banco de dados.
        $consulta = "INSERT INTO `ongs` (`nome`, `email`, `telefone`, `cidade`, `CNPJ`, `categoria`, `senha`) VALUES ('$nome', '$email', '$telefone', '$cidade', '$CNPJ', '$categoria', '$senha')";
        $resultado = banco($dbHost, $dbUsername, $dbPassword, $dbName, $consulta);
    
        // Verifica se a inserção foi bem-sucedida.
        if ($resultado === true) {
            session_start();
            echo "Cadastro realizado com sucesso!";
            header("Location: cadastro.php");
            exit;
        } else {
            session_start();
            echo = "Ocorreu um erro ao cadastrar o usuário.";
            header("Location: cadastro.php");
            exit;
        }
    //} else {
        //session_start();
        //$_SESSION['cadastro_erro'] = "As senhas não coincidem."; //tenho q tirar dps de descobrir como tirar a verificação do if sem tirar o if
        //header("Location: index.php");
        //exit;
    //}
}
?>