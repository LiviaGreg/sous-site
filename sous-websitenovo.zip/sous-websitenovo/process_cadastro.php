<?php
// Inclui os arquivos necessários
include "bdd.php";
include "funcaoerror.php";

// Verifica se o formulário foi enviado (o botão "cadastrar" foi clicado)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Extrai os dados do formulário
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $telefone = trim($_POST['telefone']);
    $cidade = trim($_POST['cidade']);
    $cnpj = preg_replace('/\D/', '', trim($_POST['cnpj']));  // Remove caracteres não numéricos do CNPJ
    $categoria = trim($_POST['categoria']);
    $senha = password_hash(trim($_POST['senha']), PASSWORD_DEFAULT); // Criptografa a senha

    // Verifica se algum campo obrigatório está vazio
    if (empty($nome) || empty($email) || empty($telefone) || empty($cidade) || empty($cnpj) || empty($categoria) || empty($senha)) {
        session_start();
        echo "Todos os campos devem ser preenchidos.";
        header("Location: cadastro.php");
        exit;
    }

    // Verifica se o CNPJ já está cadastrado
    $consulta = "SELECT COUNT(*) FROM ongs WHERE CNPJ = ?";
    $params = [$cnpj];
    $types = "s";
    $resultado = banco($mysqli, $consulta, $params, $types);
    $row = $resultado->fetch_row();
    if ($row[0] > 0) {
        session_start();
        echo "O CNPJ já está cadastrado.";
        header("Location: cadastro.php");
        exit;
    }

    // Processa o upload da logo
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == UPLOAD_ERR_OK) {
        $logoTempPath = $_FILES['logo']['tmp_name'];
        $logoName = basename($_FILES['logo']['name']);
        $uploadDir = 'uploads/'; // Pasta onde as logos serão armazenadas
        $uploadPath = $uploadDir . $logoName;

        // Move o arquivo para a pasta de destino
        if (move_uploaded_file($logoTempPath, $uploadPath)) {
            // Insere os dados da ONG no banco de dados
            $consulta = "INSERT INTO ongs (nome, email, telefone, cidade, CNPJ, categoria, logo, senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $params = [$nome, $email, $telefone, $cidade, $cnpj, $categoria, $uploadPath, $senha];
            $types = "ssssssss"; // Tipo dos parâmetros
            $resultado = banco($mysqli, $consulta, $params, $types);
            
            if ($resultado) {
                echo "Cadastro realizado com sucesso!";
                header("Location: cadastro.php");
                exit;
            } else {
                echo "Erro ao realizar o cadastro.";
                exit;
            }
        } else {
            echo "Erro ao fazer o upload da imagem.";
            exit();
        }
    }
}
?>
