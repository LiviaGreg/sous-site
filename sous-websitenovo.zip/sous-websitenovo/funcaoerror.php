<?php
function banco($mysqli, $consulta, $params = [], $types = "")
{
    // Prepara a consulta SQL
    if ($stmt = $mysqli->prepare($consulta)) {
        if ($types && $params) {
            // Associa os parâmetros à consulta preparada
            $stmt->bind_param($types, ...$params);
        }

        // Executa a consulta
        if ($stmt->execute()) {
            // Retorna o resultado da consulta (se houver)
            if (strpos($consulta, "SELECT") === 0) {
                return $stmt->get_result();
            }
            return true;  // Retorna verdadeiro para consultas de inserção ou atualização
        } else {
            echo "Erro na execução da consulta: " . $stmt->error;
            return false;
        }
    } else {
        echo "Erro na preparação da consulta: " . $mysqli->error;
        return false;
    }
}
?>
